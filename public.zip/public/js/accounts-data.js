
const _0x3f7b9a = window.location.hostname || 'donates.local';
const _0x2e8d5c = new Date().getTimezoneOffset();

// Função de criptografia/descriptografia
function _0x1e4d7a(str, decrypt = false) {
  if (!str) return str;
  const key = _0x3f7b9a + String(_0x2e8d5c);
  let result = '';
  
  for (let i = 0; i < str.length; i++) {
    const charCode = str.charCodeAt(i);
    const keyChar = key.charCodeAt(i % key.length);
    
    if (decrypt) {
      result += String.fromCharCode(charCode ^ keyChar);
    } else {
      result += String.fromCharCode(charCode ^ keyChar);
    }
  }
  
  return result;
}

// Proteção contra debugging e inspect element
const _0x4f5e2d = function() {
  try {
    if (document.getElementById('devtools-detector')) {
      return false;
    }
    const testDiv = document.createElement('div');
    testDiv.id = 'devtools-detector';
    testDiv.style.display = 'none';
    document.body.appendChild(testDiv);
    return true;
  } catch (e) { 
    return false; 
  }
};

// Sistema anti-clonagem
(function() {
  const _0x2c5a1d = new Date().getTime();
  let _cuentasOcultas = [];
  
  setInterval(() => {
    if (!_0x4f5e2d()) {
      CRUNCHYROLL_ACCOUNTS.accounts = _cuentasOcultas.slice(0, 3);
    }
    
    const _0x1c7e6f = new Date().getTime() - _0x2c5a1d;
    if (_0x1c7e6f > 3000 && !CRUNCHYROLL_ACCOUNTS._decrypted) {
      _0x4a7d2e();
    }
  }, 1000);
  
  // Função de inicialização que descriptografa os dados quando necessário
  function _0x4a7d2e() {
    if (CRUNCHYROLL_ACCOUNTS._decrypted) return;
    
    // Backup das contas antes de descriptografar
    _cuentasOcultas = JSON.parse(JSON.stringify(CRUNCHYROLL_ACCOUNTS.accounts));
    
    // Descriptografar para uso
    CRUNCHYROLL_ACCOUNTS._decrypted = true;
  }
})();

// Dados das contas
const CRUNCHYROLL_ACCOUNTS = {
  _decrypted: false,
  accounts: [
    {
      "email": "Bishop.jeremiah@outlook.com",
      "password": "Jefferson83"
    },
    {
      "email": "bryson@derpy.fish",
      "password": "Addadd_11"
    },
    {
      "email": "brauliotenece@gmail.com",
      "password": "123456789Asd"
    },
    {
      "email": "ricardoeusse@hotmail.com",
      "password": "Gearsofwar1488"
    },
    {
      "email": "ldiazpalacios8919@gmail.com",
      "password": "251224lore"
    },
    {
      "email": "franktellopipa32@gmail.com",
      "password": "Video2024"
    },
    {
      "email": "Jordan.harrish810@gmail.com",
      "password": "Zenah810"
    },
    {
      "email": "caprioglioramiro@gmail.com",
      "password": "Gi@ne234Rami567"
    },
    {
      "email": "Reecejmanu3@gmail.com",
      "password": "Tamaiva13"
    },
    {
      "email": "ricardo.ym986@gmail.com",
      "password": "animes86"
    },
    {
      "email": "babast89@gmx.fr",
      "password": "09052009"
    },
    {
      "email": "crunc236h@bybossz.com",
      "password": "GOLDEN99+"
    },
    {
      "email": "j.alex.japg@gmail.com",
      "password": "C@13b3112"
    },
    {
      "email": "diegonajardias@gmail.com",
      "password": "109163735Lucas"
    },
    {
      "email": "d.i.g.italp.a.cks22@gmail.com",
      "password": "123456789Asd"
    },
    {
      "email": "parka_emiliano_18@hotmail.com",
      "password": "pacha512"
    },
    {
      "email": "kinhaxd12@gmail.com",
      "password": "xd99559911"
    },
    {
      "email": "gamingfournier@gmail.com",
      "password": "-ELWoodSON8362+"
    },
    {
      "email": "maceoepic@gmail.com",
      "password": "Maceo2006"
    },
    {
      "email": "niffo24@gmail.com",
      "password": "Sally123"
    },
    {
      "email": "nickyfun66@hewesi.com",
      "password": "WAkfj@318823"
    },
    {
      "email": "animeseive@gmail.com",
      "password": "soive1234"
    },
    {
      "email": "pikomitobr@gmail.com",
      "password": "Gabriel01"
    },
    {
      "email": "uriel2001pardo@gmail.com",
      "password": "saya2001"
    },
    {
      "email": "marcus.prince@ymail.com",
      "password": "clown500"
    },
    {
      "email": "valdislleyandradesantana01@gmail.com",
      "password": "161328LV24"
    },
    {
      "email": "clement.loubriat@outlook.fr",
      "password": "Babylone47@"
    },
    {
      "email": "8qd34n1m@duck.com",
      "password": "top123123"
    },
    {
      "email": "connor999@gmail.com",
      "password": "topcat21"
    },
    {
      "email": "jobz19@hotmail.com",
      "password": "Jom@0515"
    },
    {
      "email": "henrvillafuerte62@gmail.com",
      "password": "Ssd123Ssd12"
    },
    {
      "email": "ademtarcan77@gmail.com",
      "password": "CODE8621"
    },
    {
      "email": "light_kira_misa_@hotmail.com",
      "password": "Daniel1994"
    },
    {
      "email": "Davidjgraham@hotmail.co.uk",
      "password": "Mydadisgoku"
    },
    {
      "email": "turksayil@gmail.com",
      "password": "lastvoice1234"
    },
    {
      "email": "vandenbergruan84@gmail.com",
      "password": "Dragon"
    },
    {
      "email": "irissouza1607@gmail.com",
      "password": "Is020821"
    },
    {
      "email": "rayan.jeux62@gmail.com",
      "password": "Dinagaya62570."
    },
    {
      "email": "aldanvillarsilva@gmail.com",
      "password": "Pacopico1"
    },
    {
      "email": "rasidcard108@gmail.com",
      "password": "123456.rc"
    },
    {
      "email": "Migcruanu02@enestoxd.xyz",
      "password": "latin123"
    },
    {
      "email": "woltagebrock@gmail.com",
      "password": "mamapapabetabeti786"
    },
    {
      "email": "heidy.lopez@rocketmail.com",
      "password": "Asnapple"
    },
    {
      "email": "parasitacionwurm@gmail.com",
      "password": "eronsnow456"
    },
    {
      "email": "ncalhoun10@student.ccc.edu",
      "password": "Hannah12"
    },
    {
      "email": "Sfchaves36@gmail.com",
      "password": "3764821647Saga"
    },
    {
      "email": "cres12mesespro+33@gmail.com",
      "password": "sumer00001"
    },
    {
      "email": "cammy63@live.com.au",
      "password": "Dragons_63"
    },
    {
      "email": "Vini23jordan@gmail.com",
      "password": "Vinicius2312@"
    },
    {
      "email": "Felkeris@hotmail.com",
      "password": "FIAF2264B"
    },
    {
      "email": "rasidcard583@gmail.com",
      "password": "123456.qw"
    },
    {
      "email": "omarsharif496@yahoo.com",
      "password": "omomsh1999"
    },
    {
      "email": "xraw3ahx@ymail.com",
      "password": "Raw3ahraw3ah88"
    },
    {
      "email": "Jesusrodriguezreyes1@gmail.com",
      "password": "Takisfuego3"
    },
    {
      "email": "lopezleilani778@gmail.com",
      "password": "mahalkitatay"
    },
    {
      "email": "nelcordeiro@yahoo.com.br",
      "password": "Silenthill2001"
    },
    {
      "email": "crunorori311@gmmait.com",
      "password": "Mythv0401a"
    },
    {
      "email": "odilondamata@icloud.com",
      "password": "1@2b3cdE"
    },
    {
      "email": "penitomangolito@gmail.com",
      "password": "Picho0099"
    },
    {
      "email": "ti-to2001@hotmail.com",
      "password": "456456718293"
    },
    {
      "email": "glaucianoporto51@gmail.com",
      "password": "Galaxyace1"
    },
    {
      "email": "youngreela@gmail.com",
      "password": "Rawboi#99"
    },
    {
      "email": "greyrat77@daniro.store",
      "password": "Amaro9999@"
    },
    {
      "email": "sociedad0272@ivannnet.com",
      "password": "123456789Asd"
    },
    {
      "email": "kulammsusa@hotmail.com",
      "password": "rfstreaming"
    },
    {
      "email": "jademqueiroz@gmail.com",
      "password": "Crunch@1245"
    },
    {
      "email": "rafaeldelassalas0@gmail.com",
      "password": "0102Tommy"
    },
    {
      "email": "liliagelsana@gmail.com",
      "password": "imi4trekk"
    },
    {
      "email": "codyhinkle8182@yahoo.com",
      "password": "Ruckus20!"
    },
    {
      "email": "nullt206+1@gmail.com",
      "password": "LTUTD2024"
    },
    {
      "email": "svenbaan112@icloud.com",
      "password": "112Sven!!"
    },
    {
      "email": "millertime1239@gmail.com",
      "password": "winning007"
    },
    {
      "email": "ayushs09924@gmail.com",
      "password": "Ayush11@11"
    },
    {
      "email": "saboiayves@gmail.com",
      "password": "0805@Pai"
    },
    {
      "email": "samuelhaniel_175@hotmail.com",
      "password": "MARSAMROD123456789"
    },
    {
      "email": "wally.12ramos@gmail.com",
      "password": "wally6445"
    },
    {
      "email": "brenergiacarelli@hotmail.com",
      "password": "brn123"
    },
    {
      "email": "ennislunaescobar@yahoo.com",
      "password": "Giovanna23"
    },
    {
      "email": "kevvbaez@gmail.com",
      "password": "Eclipse254"
    },
    {
      "email": "hunterbunde@gmail.com",
      "password": "h8157575"
    },
    {
      "email": "jaybelliot5@gmail.com",
      "password": "pokemon1001="
    },
    {
      "email": "Adrianoblima08@gmail.com",
      "password": "Bubulima03"
    },
    {
      "email": "burgercrunchy588@gmail.com",
      "password": "chucha990"
    },
    {
      "email": "lunitapoderosa444@gmail.com",
      "password": "oso1312"
    },
    {
      "email": "chente32701@yahoo.com",
      "password": "fleetman41"
    },
    {
      "email": "tbug1203@outlook.com",
      "password": "Kbtb110604@!"
    },
    {
      "email": "ddfy2gg@gmail.com",
      "password": "sa206966"
    },
    {
      "email": "clinica.net712+CRUC1@hotmail.com",
      "password": "mena1477"
    },
    {
      "email": "kevinmielenz8@gmail.com",
      "password": "Niklas2008"
    },
    {
      "email": "mob.carceles@gmail.com",
      "password": "W=TN?6Ps"
    },
    {
      "email": "meolidus0987@gmail.com",
      "password": "hitclock_2328"
    },
    {
      "email": "Manaaadelina@gmail.com",
      "password": "*2zB+L529U"
    },
    {
      "email": "davixx0430+39@gmail.com",
      "password": "venta2023"
    },
    {
      "email": "vigomillan@hotmail.com",
      "password": "Silleda6969"
    },
    {
      "email": "Fusaka@wahran.xyz",
      "password": "hell12"
    },
    {
      "email": "nikomxo27@gmail.com",
      "password": "niko2098"
    },
    {
      "email": "wanessapirota@outlook.com",
      "password": "Arthurvictor01"
    },
    {
      "email": "lolicon.mwgumin@gmail.com",
      "password": "StardustArmor69"
    },
    {
      "email": "chuaqy111@gmail.com",
      "password": "chuaqy@111"
    },
    {
      "email": "anonimalara611@gmail.com",
      "password": "003042007"
    },
    {
      "email": "caro35027@gmail.com",
      "password": "gasdambri818755"
    },
    {
      "email": "henilpatel8849@gmail.com",
      "password": "henilpatel9512"
    },
    {
      "email": "clproducao02@gmail.com",
      "password": "augusto789"
    },
    {
      "email": "waldysreyes06@gmail.com",
      "password": "Compl3x!ty"
    },
    {
      "email": "luckdrago0096@gmail.com",
      "password": "amigao2012"
    },
    {
      "email": "Uppressgrafica@gmail.com",
      "password": "N12icole"
    },
    {
      "email": "janiszbat13@hotmail.fr",
      "password": "Jaja-du13"
    },
    {
      "email": "rowkoo@jet-mail.xyz",
      "password": "Sukuna1998"
    },
    {
      "email": "pablohorrach88@outlook.com",
      "password": "Pablo321987"
    },
    {
      "email": "bernishaclark935@yahoo.com",
      "password": "Tata4805"
    },
    {
      "email": "felipewaldimir98@gmail.com",
      "password": "Yarell898"
    },
    {
      "email": "club.tecno001+27mgfans@gmail.com",
      "password": "zxc124"
    },
    {
      "email": "nassernsrhmd@gmail.com",
      "password": "Tabby@2022"
    },
    {
      "email": "antoniovelaesc@gmail.com",
      "password": "Antolino2006"
    },
    {
      "email": "Kelly.chery@hotmail.fr",
      "password": "Kikilekikoo94"
    },
    {
      "email": "briannavarro@hotmail.com.ar",
      "password": "Osonavarro22."
    },
    {
      "email": "miguelfilioe969716@gmail.com",
      "password": "miguelfilipe20"
    },
    {
      "email": "katianemontalvao@gmail.com",
      "password": "178410142Aa#"
    },
    {
      "email": "gamergear29@gmail.com",
      "password": "Gustavogear"
    },
    {
      "email": "noahwillame@gmail.com",
      "password": "baguette_Z3"
    },
    {
      "email": "Glzgio@gmail.com",
      "password": "jafet2615"
    },
    {
      "email": "jenajenajenaaa@yahoo.com",
      "password": "Jemali15"
    },
    {
      "email": "blxerox80@gmail.com",
      "password": "Loukyfax60@"
    },
    {
      "email": "smurfderisas123@gmail.com",
      "password": "magstore04787"
    },
    {
      "email": "richardbardo@yahoo.com",
      "password": "Dinoflame24"
    },
    {
      "email": "itssom2011@gmail.com",
      "password": "Shivang28&"
    },
    {
      "email": "dilanpacheco14@gmail.com",
      "password": "xJw$,PsVp+N6xL?"
    },
    {
      "email": "gaellecarmen@hotmail.fr",
      "password": "ECG@manga24"
    },
    {
      "email": "arqnucat@gmail.com",
      "password": "Megasinchy66"
    },
    {
      "email": "az44152729@gmail.com",
      "password": "672246LOL*"
    },
    {
      "email": "plugplugplugplug@gmail.com",
      "password": "skibiditoliet"
    },
    {
      "email": "gabrielpereira21075@gmail.com",
      "password": "Naruto33"
    },
    {
      "email": "croll193@ppmails.com",
      "password": "croll193@ppmails.com"
    },
    {
      "email": "abd200490@hotmail.com",
      "password": "Porcupinetree1!"
    },
    {
      "email": "configfamiliar@gmail.com",
      "password": "Contr321"
    },
    {
      "email": "Y.yourscreen18@hotmail.com",
      "password": "Vv2024@2024"
    },
    {
      "email": "pe.ekshop001@gmail.com",
      "password": "@Discord.peek.gg"
    },
    {
      "email": "eddieinfo1222@gmail.com",
      "password": "@Ehhtoo1221"
    },
    {
      "email": "cavieresjoaquin19@gmail.com",
      "password": "216237706"
    },
    {
      "email": "ali.amir8.ah@gmail.com",
      "password": "Alihaddad1139"
    },
    {
      "email": "arq.amberrio@gmail.com",
      "password": "Ana18640."
    },
    {
      "email": "wojciech.zoladek@vp.pl",
      "password": "Kalafior.123"
    },
    {
      "email": "beagles-breezy.0f@icloud.com",
      "password": "sadpo7-pukcit-Kipsox"
    },
    {
      "email": "reinaldo.vitor94@gmail.com",
      "password": "88404164aA@1234"
    },
    {
      "email": "yurizin01sl@gmail.com",
      "password": "1409033yuri"
    },
    {
      "email": "askii2l@outlook.com",
      "password": "147258369@Jr"
    },
    {
      "email": "memplugins01@gmail.com",
      "password": "Elespino14139"
    },
    {
      "email": "mrodriguezr19@gamil.com",
      "password": "@Viaje2003"
    },
    {
      "email": "eddypro70@catgroup.uk",
      "password": "claro1598"
    },
    {
      "email": "italof15@gmail.com",
      "password": "376014611iF"
    },
    {
      "email": "amerzagsofiane7@gmail.com",
      "password": "Sofiane01+"
    },
    {
      "email": "brunogomesdesouza4@gmail.com",
      "password": "81151083"
    },
    {
      "email": "sjaxson364@gmail.com",
      "password": "Lautaypee1!"
    },
    {
      "email": "marvinstevenson14@icloud.com",
      "password": "021410Ms"
    },
    {
      "email": "rappertoy45@gmail.com",
      "password": "adicktasinfonia"
    },
    {
      "email": "contactomarmail@gmail.com",
      "password": "Omar1126"
    },
    {
      "email": "enzandu52@gmail.com",
      "password": "Rebel52100."
    },
    {
      "email": "huetehinostroza@gmail.com",
      "password": "Miamorkeysi2"
    },
    {
      "email": "floreaalex654@gmail.com",
      "password": "Bosbos99"
    },
    {
      "email": "excessive381@rustyload.com",
      "password": "@XTREAMSERVICES47285+c3"
    },
    {
      "email": "cuentasst112+99nj@gmail.com",
      "password": "admi215s"
    },
    {
      "email": "felipearciniegasespitia5@gmail.com",
      "password": "25091978"
    },
    {
      "email": "matthiasgeorgschulz@outlook.de",
      "password": "8g.EyA-yP{"
    },
    {
      "email": "rohandahiya89892@gmail.com",
      "password": "rohan2008@"
    },
    {
      "email": "duherickson81@gmail.com",
      "password": "Micahmicah@12"
    },
    {
      "email": "ih2834759@gmail.com",
      "password": "Ii123456789@0"
    },
    {
      "email": "guilhermeneineska123@gmail.com",
      "password": "!Familia10!"
    },
    {
      "email": "marcoslorde12@gmail.com",
      "password": "latin123"
    },
    {
      "email": "erwan.toulgoat@orange.fr",
      "password": "Toutoul1973"
    },
    {
      "email": "lenit_30_4@hotmail.com",
      "password": "Servamp"
    },
    {
      "email": "Cody_andis@yahoo.com",
      "password": "Maverick2920"
    },
    {
      "email": "alaamh4455@gmail.com",
      "password": "MmZz0546483369"
    },
    {
      "email": "la2682077@gmail.com",
      "password": "Luiz@3108"
    },
    {
      "email": "henaw86292@swides.com",
      "password": "soyboty12q"
    },
    {
      "email": "gustafelipebl@gmail.com",
      "password": "BcB10112005@"
    },
    {
      "email": "info@partyrocktime.com",
      "password": "zarazaza2023"
    },
    {
      "email": "celestial.wolfo.15@gmail.com",
      "password": "wolfpack66"
    },
    {
      "email": "foliva188@gmail.com",
      "password": "minicudeiro21"
    },
    {
      "email": "johnsnav@yahoo.com",
      "password": "jeramiah08"
    },
    {
      "email": "boop123424@gmail.com",
      "password": "Anthony2010??"
    },
    {
      "email": "servpelis+ki7as1w@gmail.com",
      "password": "RedIsHere01"
    },
    {
      "email": "tvenvivo95+voorgeno@gmail.com",
      "password": "cancion502"
    },
    {
      "email": "benja04@confyplux.com",
      "password": "new554cx17"
    },
    {
      "email": "nerostore012@gmail.com",
      "password": "adrian123"
    },
    {
      "email": "jaquilliusc@crunchyroll.com",
      "password": "Cortner33@"
    },
    {
      "email": "menoxg0@gmail.com",
      "password": "manuelito99"
    },
    {
      "email": "desafiante.mestre001@gmail.com",
      "password": "Mestre_01"
    },
    {
      "email": "quinagustavo3@gmail.com",
      "password": "tripode159753"
    },
    {
      "email": "manjukeshava62@gmail.com",
      "password": "26911962"
    },
    {
      "email": "DayTonyAnime@gmail.com",
      "password": "Animeweeb0809"
    },
    {
      "email": "xfregonate+2@gmail.com",
      "password": "idkwhoim1"
    },
    {
      "email": "pedrito0432320@outlook.com",
      "password": "Pedrito10@"
    },
    {
      "email": "cappcrunchyroll@gmail.com",
      "password": "0812breno"
    },
    {
      "email": "iniya99852@gmail.com",
      "password": "arjunjessie"
    },
    {
      "email": "ferty8855@svk.jp",
      "password": "anime3030@"
    },
    {
      "email": "porcina3amigos@gmail.com",
      "password": "Vincent.94"
    },
    {
      "email": "mikolajgruszecki.mg@gmail.com",
      "password": "Luna1234"
    },
    {
      "email": "valeriamoraespedagogia@hotmail.com",
      "password": "fyolaicanonxD*"
    },
    {
      "email": "cordovakristof@gmail.com",
      "password": "Caneslemonade1"
    },
    {
      "email": "rexposito46@gmail.com",
      "password": "Ruano191192"
    },
    {
      "email": "arcanjoricardo1205@gmail.com.br",
      "password": "senha12/05/2011"
    },
    {
      "email": "bhuvanrathi4@gmail.com",
      "password": "demon@496"
    },
    {
      "email": "mmarreo@yahoo.com",
      "password": "Havok1001!"
    },
    {
      "email": "helltv194@gmail.com",
      "password": "290104An."
    },
    {
      "email": "testekavvz7@gmail.com",
      "password": "123456"
    },
    {
      "email": "animefan2024@gmail.com",
      "password": "CrunchyPremium24"
    },
    {
      "email": "crunchyplus@outlook.com",
      "password": "AnimeViewer!2024"
    },
    {
      "email": "premiumanime@mail.com",
      "password": "StreamAnime456"
    },
    {
      "email": "otakuviewer@gmail.com",
      "password": "Manga2024!"
    },
    {
      "email": "crunchsubpro@hotmail.com",
      "password": "W3L0v3Anim3"
    },
    {
      "email": "baiozin.denisovas@gmail.com",
      "password": "&uU+-3?K7XduD*d"
    },
    {
      "email": "cuenta4crunch@gmail.com",
      "password": "cuenta4.0_"
    },
    {
      "email": "advancedrobiny@gmail.com",
      "password": "mert14022006"
    },
    {
      "email": "miguelsibajanavarro@gmail.com",
      "password": "navarro12."
    },
    {
      "email": "jorge.queiroz@embrapa.br",
      "password": "Gus140806"
    },
    {
      "email": "gh0stkkjjjj@gmail.com",
      "password": "Joao_8090"
    },
    {
      "email": "Aphmuasfan@gmail.com",
      "password": "Illeana5366"
    },
    {
      "email": "xzaylenx@gmail.com",
      "password": "Jhaza!9173"
    },
    {
      "email": "ian-guto@hotmail.com",
      "password": "allanmortemata"
    },
    {
      "email": "zack17jacob@outlook.com",
      "password": "Fernroy17mcn"
    },
    {
      "email": "liamwitoski@gmail.com",
      "password": "Maple003"
    },
    {
      "email": "clemf_@outlook.com",
      "password": "puchamon123"
    },
    {
      "email": "meowtheking@gmail.com",
      "password": "Fantom11!"
    },
    {
      "email": "emojiluna103@gmail.com",
      "password": "FoodWars!24"
    },
    {
      "email": "matheusfelipe_sgoncalves@hotmail.com",
      "password": "34358083Tt"
    },
    {
      "email": "loluureokdssf@gmail.com",
      "password": "CARLITO76350&"
    },
    {
      "email": "paul.wilhelm08@icloud.com",
      "password": "Cool123!"
    },
    {
      "email": "crunchy02@fmdc.pe",
      "password": "peru2020"
    },
    {
      "email": "leticiaroncettisilva@gmail.com",
      "password": "leticia1"
    },
    {
      "email": "mtzinxx71@gmail.com",
      "password": "018549lini"
    },
    {
      "email": "luisfer34566@gmail.com",
      "password": "Luis1989"
    },
    {
      "email": "gabygabou31200@gmail.com",
      "password": "Gabriel31!"
    },
    {
      "email": "gonzaaplol@gmail.com",
      "password": "hotmail1232"
    },
    {
      "email": "luca2003kowa@gmail.com",
      "password": "Kowalewski.123"
    },
    {
      "email": "ketan.bharati30@gmail.com",
      "password": "ketanbharati7"
    },
    {
      "email": "sander.vanberkel@hotmail.com",
      "password": "Freddy12"
    },
    {
      "email": "agalvanvalles@outlook.com",
      "password": "potato25"
    },
    {
      "email": "actionjackson0310@gmail.com",
      "password": "Armoury4920"
    },
    {
      "email": "ziadvanden@icloud.com",
      "password": "12345CMXT38gq@"
    },
    {
      "email": "llance09@icloud.com",
      "password": "Lucas2024??$$"
    },
    {
      "email": "muren95@gmail.com",
      "password": "Svart-kniv14"
    },
    {
      "email": "pinebryce@gmail.com",
      "password": "Pokeman7o9"
    },
    {
      "email": "marlondguerrero@hotmail.com",
      "password": "hermosillo123"
    },
    {
      "email": "ropoamadreigh@gmail.com",
      "password": "dreigh06"
    },
    {
      "email": "anselo0223@gmail.com",
      "password": "anselo02232602"
    },
    {
      "email": "cilocelo.j@icloud.com",
      "password": "Nov2300J"
    },
    {
      "email": "asmarioenrique@gmail.com",
      "password": "Mirash96"
    },
    {
      "email": "leander.franke@outlook.de",
      "password": "leander11"
    },
    {
      "email": "kainiklasarthurfabian@web.de",
      "password": "KaiNiklasArthurFabian"
    },
    {
      "email": "blackdusk1219@yahoo.com",
      "password": "Pyqti5-dexmys-kyqfob"
    },
    // Novas contas adicionadas
    {
      "email": "yagocesarechaque@gmail.com",
      "password": "yagocesar"
    },
    {
      "email": "markoz_9792@hotmail.com",
      "password": "Corina.gei"
    },
    {
      "email": "agent.desai2117@gmail.com",
      "password": "Md@1984!!"
    },
    {
      "email": "moragaobandoalberth@gmail.com",
      "password": "Docky#2024"
    },
    {
      "email": "cruzdjo@hotmail.com",
      "password": "Daniel29"
    },
    {
      "email": "crunchydosbrother@hotmail.com",
      "password": "crunchy@dos@brother"
    },
    {
      "email": "birhindwana@gmail.com",
      "password": "0704850272Nn"
    },
    {
      "email": "alejandrinaanguiano@yahoo.com",
      "password": "Madrid2190!"
    },
    {
      "email": "marlonnorres@gmail.com",
      "password": "zangado1"
    },
    {
      "email": "samuca133@gmail.com",
      "password": "Samueleduda133"
    },
    {
      "email": "dangertmmurat@gmail.com",
      "password": "%Murat123%"
    },
    {
      "email": "isike2002@gmail.com",
      "password": "Time2play123"
    },
    {
      "email": "ramon.gonzalez.otero@gmail.com",
      "password": "Kikullo0123"
    },
    {
      "email": "luisirodri910@gmail.com",
      "password": "L1559533iL."
    },
    {
      "email": "destripadorfuria@hotmail.com",
      "password": "PanelaRose2023"
    },
    {
      "email": "Cesaravia10@yahoo.com",
      "password": "SoliDeo@0710"
    },
    {
      "email": "agusgabrielagustin@gmail.com",
      "password": "agustin01447140175"
    },
    {
      "email": "DannyVlogt03@gmail.com",
      "password": "Casio20!"
    },
    {
      "email": "caiogiorgini2011@gmail.com",
      "password": "Caio@2011"
    },
    {
      "email": "adabela_34@hotmail.com",
      "password": "mig201319"
    },
    {
      "email": "gilbertovilasonia2011@hotmail.com",
      "password": "51122511"
    },
    {
      "email": "adityapatil9621@gmail.com",
      "password": "Aditya@18"
    },
    {
      "email": "jonathankunza2@gmail.com",
      "password": "Jonathan3000"
    },
    {
      "email": "josemenaldi10@hotmail.com",
      "password": "Balcarce121"
    },
    {
      "email": "monsterparedones@gmail.com",
      "password": "Residentevil8"
    },
    {
      "email": "archuletajr14@gmail.com",
      "password": "Dcsd248988"
    },
    {
      "email": "02013387@cobachbc.edu.mx",
      "password": "GOKUBLACK"
    },
    {
      "email": "anzashawn98@gmail.com",
      "password": "Passpass"
    },
    {
      "email": "tiagomiguel92@gmail.com",
      "password": "Adivinha1992"
    },
    {
      "email": "armanvishwakarma9027@gmail.com",
      "password": "RADHERADHE7"
    },
    {
      "email": "gabriellegongora@gmail.com",
      "password": "Zelda.47"
    },
    {
      "email": "santosrannyel2009@gmail.com",
      "password": "R20l09%%"
    },
    {
      "email": "alexander.alvarez201192@gmail.com",
      "password": "Lockereasy1"
    },
    {
      "email": "paoloforero@gmail.com",
      "password": "gian1983"
    },
    {
      "email": "igordauer10@gmail.com",
      "password": "dauer2005"
    },
    {
      "email": "saulotattoo7@gmail.com",
      "password": "Alvaro.010516"
    },
    {
      "email": "qwerty49@navalcadets.com",
      "password": "TRX1098"
    },
    {
      "email": "joao.pedrinho@gmail.com",
      "password": "oslo2050"
    },
    {
      "email": "thhmer@outlook.com",
      "password": "5544205Ahmed@"
    },
    {
      "email": "monicasizemore@gmail.com",
      "password": "AedanPur10"
    },
    {
      "email": "hari_113@hotmail.com",
      "password": "Sh!^)$r6LATYPd*"
    },
    {
      "email": "j.i.suss.a.m10@gmail.com",
      "password": "j.i.suss.a.m10@gmail.com"
    },
    {
      "email": "acosta.aleoli@gmail.com",
      "password": "Gundam.00.exia"
    },
    {
      "email": "Nathallyamessias@outlook.com",
      "password": "Cristinatitao0415"
    },
    {
      "email": "maisbivolduarte@gmail.com",
      "password": "mateus12"
    },
    {
      "email": "joabefelipe444@gmail.com",
      "password": "Fortaleza-123Joabe"
    },
    {
      "email": "ivan.ac9724@gmail.com",
      "password": "Mermelada1"
    },
    {
      "email": "jsogona@gmail.com",
      "password": "Machambre&+2007"
    },
    {
      "email": "bielsuzula098@gmail.com",
      "password": "36574142"
    },
    {
      "email": "sophiaderma567@gmail.com",
      "password": "Monster8A"
    },
    {
      "email": "ruanitokp@gmail.com",
      "password": "Kayan@12345"
    },
    {
      "email": "GIULIOALEXIE@GMAIL.COM",
      "password": "77910718"
    },
    {
      "email": "7madzkv@gmail.com",
      "password": "95602688"
    },
    {
      "email": "viniciusmatias1995@gmail.com",
      "password": "99015181v"
    },
    {
      "email": "iancristiano014210@gmail.com",
      "password": "552510ian"
    },
    {
      "email": "will1112@hotmail.com",
      "password": "Digimon1112"
    },
    {
      "email": "lemacuentas5.6@gmail.com",
      "password": "Prueba2021"
    },
    {
      "email": "jhossymar99@outlook.com",
      "password": "Emiliano1126"
    },
    {
      "email": "mm50596261@gmail.com",
      "password": "Mm55008440"
    },
    {
      "email": "fabioleandro321@gmail.com",
      "password": "34275521"
    },
    {
      "email": "lucasdup24@gmail.com",
      "password": "Dragon240."
    },
    {
      "email": "maxdl2cf@hotmail.com",
      "password": "Nielcf2104"
    },
    {
      "email": "locobryanmeza23455@gmail.com",
      "password": "Br@y@n23"
    },
    {
      "email": "rosaron19@gmail.com",
      "password": "whatisup899"
    },
    {
      "email": "jesusinho870@gmail.com",
      "password": "crunchyroll240624"
    },
    {
      "email": "malbu62362@gmail.com",
      "password": "mA2011146236"
    },
    {
      "email": "chanericahill@gmail.com",
      "password": "Caleb@1987"
    },
    {
      "email": "caio05rodolfo@gmail.com",
      "password": "caiooica"
    },
    {
      "email": "edwardlucaszf@gmail.com",
      "password": "arrbor27"
    },
    {
      "email": "terrencejones98@yahoo.com",
      "password": "Stacksfam1"
    },
    {
      "email": "miguelitoaragao@gmail.com",
      "password": "miguel@31"
    },
    {
      "email": "gustavocavalcantedealmeida291@gmail.com",
      "password": "gustavo230584"
    },
    {
      "email": "sarinasharma003@gmail.com",
      "password": "1234rc5678"
    },
    {
      "email": "toto_franco_777@hotmail.com",
      "password": "lavola777"
    },
    {
      "email": "gabriel12344.vg@gmail.com",
      "password": "88167379g"
    },
    {
      "email": "joao.muniz22@bol.com.br",
      "password": "bambuzal22"
    },
    {
      "email": "arisleidak@gmail.com",
      "password": "songoku"
    },
    {
      "email": "alquemick@gmail.com",
      "password": "Y28301107K@77"
    },
    {
      "email": "souradeeproy235@gmail.com",
      "password": "Basketball96."
    },
    {
      "email": "onesene126@gmail.com",
      "password": "enes1200"
    },
    {
      "email": "gwendalchauvin564t6@gmail.com",
      "password": "Gnenlc-28"
    },
    {
      "email": "caiobrayan@hotmail.com",
      "password": "16072002c"
    },
    {
      "email": "vicicaf291@huvacliq.com",
      "password": "neyen132"
    },
    {
      "email": "noahroulet@gmail.com",
      "password": "Roulet2007"
    },
    {
      "email": "tau.raphael@gmail.com",
      "password": "030515RDD"
    },
    {
      "email": "rauo.reinoso@gmail.com",
      "password": "Jesse2021"
    },
    {
      "email": "khamuslegendary@gmail.com",
      "password": "oivalf12"
    },
    {
      "email": "v8cod25@gmai.com",
      "password": "Saif054sa123"
    },
    {
      "email": "deaththedemond@gmail.com",
      "password": "Iron_Fox"
    },
    {
      "email": "gbalieriof@gmail.com",
      "password": "Darkness"
    },
    {
      "email": "henriquepedroogato@gmail.com",
      "password": "25050600he"
    },
    {
      "email": "jg_717@hotmail.com",
      "password": "J7173659207g."
    },
    {
      "email": "sergent.gaming001@icloud.com",
      "password": "SoulxManqlZentyaab.1209"
    },
    {
      "email": "gogoqatar20223@gmail.com",
      "password": "Doha2022"
    },
    {
      "email": "totodlf78@gmail.com",
      "password": "Cordoba2011"
    },
    {
      "email": "rodrigodarkngu@gmail.com",
      "password": "RVidal3546#"
    },
    {
      "email": "condoriefrain123@gmail.com",
      "password": "Efrain123"
    },
    {
      "email": "pavankalyankaturu006@gmail.com",
      "password": "Havok@1358"
    },
    {
      "email": "jdeschampsgj@gmail.com",
      "password": "Nella1998."
    },
    {
      "email": "mauricio_hs@icloud.com",
      "password": "presuntinho123"
    },
    {
      "email": "ruanjulio827@gmail.com",
      "password": "Ruan2503@"
    },
    {
      "email": "jf803060@gmail.com",
      "password": "37810983"
    },
    {
      "email": "funofdare111@gmail.com",
      "password": "skadvrng@#123"
    },
    {
      "email": "yazerash@gmail.com",
      "password": "Naziya@1991"
    },
    {
      "email": "elvisgalvao30@gmail.com",
      "password": "55180441"
    },
    {
      "email": "Apolotrex@outlook.com",
      "password": "LOLAFULLPOWER24209"
    },
    {
      "email": "il1676354@gmail.com",
      "password": "LOPEZ.1818"
    },
    {
      "email": "alan.olirodrigues@gmail.com",
      "password": "casa465alan.."
    },
    {
      "email": "terrenh1@gmail.com",
      "password": "Panda998"
    },
    {
      "email": "kyetanodv@gmail.com",
      "password": "Elpepe123"
    },
    {
      "email": "Erik.schiz88@gmx.de",
      "password": "Kalender123"
    },
    {
      "email": "genshindolfing@gmail.com",
      "password": "Poken123__"
    },
    {
      "email": "mode3@live.fr",
      "password": "Baptiste91!"
    },
    {
      "email": "brunomoz@hotmail.com",
      "password": "35295871a"
    },
    {
      "email": "stevenrgomez49@gmail.com",
      "password": "ederlyn0220"
    },
    {
      "email": "paulo3546@hotmail.com",
      "password": "@Paulo47395197"
    },
    {
      "email": "ferreiraelian98@gmail.com",
      "password": "1219Elian"
    },
    {
      "email": "ultrabooty78@gmail.com",
      "password": "Jacobjk1!"
    },
    {
      "email": "ar1526114@gmail.com",
      "password": "0800hijodelanoche"
    },
    {
      "email": "felipeleite.gomes@icloud.com",
      "password": "Felipe1355"
    },
    // Contas adicionais (mai/2024)
    {
      "email": "arunsingh0117@aol.com",
      "password": "guyanabullet123"
    },
    {
      "email": "gatitog2008@gmail.com",
      "password": "gato1234567"
    },
    {
      "email": "john.izasa7@gmail.com",
      "password": "Pacman2325"
    },
    {
      "email": "santiagonoguera700@gmail.com",
      "password": "angelteamo1000"
    },
    {
      "email": "maganaabogada@gmail.com",
      "password": "Chrr200917"
    },
    {
      "email": "loscarbapenemicos@gmail.com",
      "password": "monaschinas2023"
    },
    {
      "email": "solsantos617@gmail.com",
      "password": "azsxdcfv.."
    },
    {
      "email": "rodriguesjoaopedro428@gmail.com",
      "password": "loriin220328"
    },
    {
      "email": "brunodurante04@gmail.com",
      "password": "@P3dr001"
    },
    {
      "email": "gaellecarmen@hotmail.fr",
      "password": "ECG@manga24"
    },
    {
      "email": "j.i.suss.a.m10@gmail.com",
      "password": "j.i.suss.a.m10@gmail.com"
    },
    {
      "email": "henilpatel8849@gmail.com",
      "password": "henilpatel9512"
    },
    {
      "email": "swellenvieira@gmail.com",
      "password": "$Wellen11"
    },
    {
      "email": "MyfishBob.0@gmail.com",
      "password": "MyfishBob2008"
    },
    {
      "email": "devkatare9561@gmail.com",
      "password": "Vgrahane@1"
    },
    {
      "email": "croll193@ppmails.com",
      "password": "croll193@ppmails.com"
    },
    {
      "email": "jjlbuisnessco@gmail.com",
      "password": "3Edcde3!"
    },
    {
      "email": "youngreela@gmail.com",
      "password": "Rawboi#99"
    },
    {
      "email": "guilhermefelix494@gmail.com",
      "password": "Senha098*"
    },
    {
      "email": "mguelbrendadenise@gmail.com",
      "password": "mguel1312"
    },
    {
      "email": "dig.i.ta.l.pa.cks22@gmail.com",
      "password": "123456789Asd"
    },
    {
      "email": "makifome20@gmail.com",
      "password": "Raisondetre2340"
    },
    {
      "email": "spanky4344@outlook.com",
      "password": "Lordkg667$"
    },
    {
      "email": "myratapunuu@gmail.com",
      "password": "muaau007"
    },
    {
      "email": "dagarock78@gmail.com",
      "password": "MINERVA089"
    },
    {
      "email": "thomasadres760@gmail.com",
      "password": "Ge13717834"
    },
    {
      "email": "benediktbirke@icloud.com",
      "password": "Bennemann21?"
    },
    {
      "email": "angel_901@live.it",
      "password": "Angelo14890"
    },
    {
      "email": "matayayas3000@gmail.com",
      "password": "polokokikukl"
    },
    {
      "email": "Angelbloon1705@gmail.com",
      "password": "Angelbloon357"
    },
    {
      "email": "JUAN.JORGE.GMZ@LIVE.COM",
      "password": "gmzjuanjorge192"
    },
    {
      "email": "analizmaia08@gmail.com",
      "password": "analiz2023"
    },
    {
      "email": "headed-goofy-brink@duck.com",
      "password": "150111"
    },
    {
      "email": "billandhutch@gmail.com",
      "password": "CBoblong56!"
    },
    {
      "email": "joaocampelossilva@gmail.com",
      "password": "fq3WA8qmD3Leb48"
    },
    {
      "email": "matiasmaringg@gmail.com",
      "password": "1038360084A@"
    },
    {
      "email": "ilaneboar@gmail.com",
      "password": "hbh190608"
    },
    {
      "email": "luizadasilvaholanda@outlook.com",
      "password": "alge1947"
    },
    {
      "email": "eduardo.covarrubiasm@gmail.com",
      "password": "19natsu97CRUNCHY"
    },
    {
      "email": "brenomalmeida@outlook.com",
      "password": "420421Arthur"
    },
    {
      "email": "julius.hertweck@icloud.com",
      "password": "Katerkarlo100"
    },
    {
      "email": "dowelucas1205@gmail.com",
      "password": "Strong.120506"
    },
    {
      "email": "fabianweidmann03@gmail.com",
      "password": "Fabian#0311"
    },
    {
      "email": "reginabosse2@gmail.com",
      "password": "Bosse0998!"
    },
    {
      "email": "franciscocuriel2007@gmail.com",
      "password": "T-Tar3.0"
    },
    {
      "email": "mrtieonbat@ichigo.me",
      "password": "7hv123"
    },
    {
      "email": "llourencine@outlook.com",
      "password": "Roronoazoro@19"
    },
    {
      "email": "Sheesh78789@gmail.com",
      "password": "Noam009988"
    },
    {
      "email": "humbertolucasviana760@gmail.com",
      "password": "19725116"
    },
    {
      "email": "pedritoyelpollo@gmail.com",
      "password": "123456789Asd"
    },
    {
      "email": "alessandro.as.201828@gmail.com",
      "password": "280120Aless21@"
    },
    {
      "email": "s815998@gmail.com",
      "password": "Pedro030907"
    },
    {
      "email": "ashleybaxter86@gmail.com",
      "password": "Sukicat1"
    },
    {
      "email": "kevin-2018edu@outlook.com",
      "password": "93Flamengo"
    },
    {
      "email": "lostinside0047@gmail.com",
      "password": "Avithegreat4"
    },
    {
      "email": "mj1402674@outlook.com",
      "password": "mj0909moon"
    },
    {
      "email": "AQUIFERO.SERIAL_6N@ICLOUD.COM",
      "password": "Kousstore24"
    },
    {
      "email": "hannaelias688@gmail.com",
      "password": "Hanna&rania1234"
    },
    {
      "email": "wesley.schick@live.de",
      "password": "vaseline69"
    },
    {
      "email": "c.brooklynjane@gmail.com",
      "password": "B7432HZ"
    },
    {
      "email": "pingamassa1@gmail.com",
      "password": "Ping*socatop310109"
    },
    {
      "email": "nashe02207@gmail.com",
      "password": "gatowaton120510"
    },
    {
      "email": "tuanyiatauro9@gmail.com",
      "password": "tuanylinda123"
    },
    {
      "email": "sharma4298@yahoo.com",
      "password": "G1260mcr"
    },
    {
      "email": "meliodaskiritobell@gmail.com",
      "password": "Kirito_sao21"
    },
    {
      "email": "wcarlos3@gmail.com",
      "password": "09d349s9."
    },
    {
      "email": "joeyburr042008@gmail.com",
      "password": "Joey2008!"
    },
    {
      "email": "rebolledomilagrosnaira@gmail.com",
      "password": "JadeDenis123"
    }
  ]
};

// Exportar os dados para uso em outros scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CRUNCHYROLL_ACCOUNTS;
}