
const _0x3f7b9a = window.location.hostname || 'donates.local';
const _0x2e8d5c = new Date().getTimezoneOffset();

// Função de criptografia/descriptografia
function _0x1e4d7a(str, decrypt = false) {
  if (!str) return str;
  const key = _0x3f7b9a + String(_0x2e8d5c);
  let result = '';
  
  for (let i = 0; i < str.length; i++) {
    const charCode = str.charCodeAt(i);
    const keyChar = key.charCodeAt(i % key.length);
    
    if (decrypt) {
      result += String.fromCharCode(charCode ^ keyChar);
    } else {
      result += String.fromCharCode(charCode ^ keyChar);
    }
  }
  
  return result;
}

// Proteção contra debugging e inspect element
const _0x4f5e2d = function() {
  try {
    if (document.getElementById('devtools-detector')) {
      return false;
    }
    const testDiv = document.createElement('div');
    testDiv.id = 'devtools-detector';
    testDiv.style.display = 'none';
    document.body.appendChild(testDiv);
    return true;
  } catch (e) { 
    return false; 
  }
};

// Sistema anti-clonagem
(function() {
  const _0x2c5a1d = new Date().getTime();
  let _cuentasOcultas = [];
  
  setInterval(() => {
    if (!_0x4f5e2d()) {
      CRUNCHYROLL_ACCOUNTS.accounts = _cuentasOcultas.slice(0, 3);
    }
    
    const _0x1c7e6f = new Date().getTime() - _0x2c5a1d;
    if (_0x1c7e6f > 3000 && !CRUNCHYROLL_ACCOUNTS._decrypted) {
      _0x4a7d2e();
    }
  }, 1000);
  
  // Função de inicialização que descriptografa os dados quando necessário
  function _0x4a7d2e() {
    if (CRUNCHYROLL_ACCOUNTS._decrypted) return;
    
    // Backup das contas antes de descriptografar
    _cuentasOcultas = JSON.parse(JSON.stringify(CRUNCHYROLL_ACCOUNTS.accounts));
    
    // Descriptografar para uso
    CRUNCHYROLL_ACCOUNTS._decrypted = true;
  }
})();

// Dados das contas
const CRUNCHYROLL_ACCOUNTS = {
  _decrypted: false,
  accounts: [
    {
      email: "Bishop.jeremiah@outlook.com",
      password: "Jefferson83"
    },
    {
      email: "cv382851@gmail.com",
      password: "290415An"
    },
    {
      email: "diallokhady029@gmail.com",
      password: "seynim10"
    },
    {
      email: "ladine.gercek@gmail.com",
      password: "62Dersimoo62!"
    },
    {
      email: "pilidue71@gmail.com",
      password: "CrF3$u@-bdVDYbT"
    },
    {
      email: "blagache@cegetel.net",
      password: "Beberla1622/"
    },
    {
      email: "peillo13@gmail.com",
      password: "Marseille13+"
    },
    {
      email: "Noeliasangry_@hotmail.com",
      password: "07092012"
    },
    {
      email: "castelainthomaspronetflix@gmail.com",
      password: "X8zv53027d!"
    },
    {
      email: "tresa.boykin@gmail.com",
      password: "Anltrt61!!"
    },
    {
      email: "wayne.sharp.85@gmail.com",
      password: "GemAidenGrace_2023"
    },
    {
      email: "harutyunmekonyan@gmail.com",
      password: "crystale<3"
    },
    {
      email: "craigjones01@gmail.com",
      password: "Alicejohnmegan@010"
    }
  ]
};

// Exportar os dados para uso em outros scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CRUNCHYROLL_ACCOUNTS;
}