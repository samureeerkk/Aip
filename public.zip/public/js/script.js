document.addEventListener('DOMContentLoaded', function() {
    // Elementos
    const generateBtn = document.getElementById('generateBtn');
    const copyBtn = document.getElementById('copyBtn');
    const emailText = document.getElementById('emailText');
    const passwordText = document.getElementById('passwordText');
    const counterElement = document.getElementById('counter');
    
    // Variáveis
    let accounts = [];
    let currentAccount = null;
    let counter = 0;
    let accountSource = '';
    let usedAccounts = [];
    
    // Mensagem inicial
    emailText.textContent = 'Carregando contas...';
    
    // Verificar se temos as contas em memória (do arquivo accounts-data.js)
    if (typeof CRUNCHYROLL_ACCOUNTS !== 'undefined' && CRUNCHYROLL_ACCOUNTS.accounts) {
        accounts = CRUNCHYROLL_ACCOUNTS.accounts;
        accountSource = 'Dados em memória';
        setupAccountsReady();
    } else {
        loadAccountsFromJSON();
    }
    
    // Função para carregar contas do JSON (como fallback)
    function loadAccountsFromJSON() {
        const possiblePaths = [
            'data/accounts.json',
            './data/accounts.json', 
            '../data/accounts.json',
            '/data/accounts.json',
            'accounts.json'
        ];
        
        tryNextPath(0);
        
        function tryNextPath(index) {
            if (index >= possiblePaths.length) {
                console.error('Não foi possível carregar o arquivo JSON');
                if (accounts.length === 0) {
                    createHardcodedAccounts();
                }
                return;
            }
            
            fetch(possiblePaths[index])
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Erro HTTP: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (!data || !data.accounts || !data.accounts.length) {
                        throw new Error('Dados inválidos ou array vazio');
                    }
                    
                    accounts = data.accounts;
                    accountSource = `JSON`;
                    setupAccountsReady();
                })
                .catch(error => {
                    tryNextPath(index + 1);
                });
        }
    }
    
    // Criar algumas contas hardcoded como último recurso
    function createHardcodedAccounts() {
        accounts = [
            { email: "conta_demo1@example.com", password: "senha123" },
            { email: "conta_demo2@example.com", password: "senha456" },
            { email: "conta_demo3@example.com", password: "senha789" }
        ];
        accountSource = 'Demo';
        setupAccountsReady();
    }
    
    // Configurar a interface quando as contas estiverem prontas
    function setupAccountsReady() {
        // Habilitar o botão de gerar
        generateBtn.disabled = false;
        
        // Mostrar feedback
        if (accountSource === 'Demo') {
            emailText.textContent = 'MODO DE DEMONSTRAÇÃO';
            passwordText.textContent = 'Usando contas de exemplo';
        } else {
            emailText.textContent = 'Contas carregadas com sucesso!';
            passwordText.textContent = 'Clique em "Gerar Conta" para começar';
        }
        
        // Adicionar estatísticas
        updateStats();
    }
    
    // Atualizar estatísticas
    function updateStats() {
        const statsElement = document.createElement('div');
        statsElement.className = 'stats';
        statsElement.innerHTML = `
            <div class="stat-item">
                <i class="fas fa-database"></i>
                <span>${accounts.length} contas disponíveis</span>
            </div>
        `;
        document.querySelector('.status-container').prepend(statsElement);
    }
    
    // Evento de clique no botão gerar
    generateBtn.addEventListener('click', function() {
        if (accounts.length === 0) {
            emailText.textContent = 'Nenhuma conta disponível.';
            passwordText.textContent = '';
            return;
        }
        
        // Selecionar uma conta aleatória (preferencialmente não usada antes)
        let randomIndex;
        let attempts = 0;
        
        do {
            randomIndex = Math.floor(Math.random() * accounts.length);
            attempts++;
        } while (usedAccounts.includes(randomIndex) && attempts < 5 && usedAccounts.length < accounts.length);
        
        // Adicionar à lista de contas usadas
        if (!usedAccounts.includes(randomIndex)) {
            usedAccounts.push(randomIndex);
        }
        
        // Se todas as contas já foram usadas, resetar o rastreamento
        if (usedAccounts.length >= accounts.length) {
            usedAccounts = [];
        }
        
        currentAccount = accounts[randomIndex];
        
        // Mostrar na interface
        emailText.textContent = `Email: ${currentAccount.email}`;
        passwordText.textContent = `Senha: ${currentAccount.password}`;
        
        // Habilitar botão de copiar
        copyBtn.disabled = false;
        
        // Incrementar o contador
        counter++;
        counterElement.textContent = counter;
    });
    
    // Evento de clique no botão copiar
    copyBtn.addEventListener('click', function() {
        if (!currentAccount) return;
        
        const textToCopy = `Email: ${currentAccount.email}\nSenha: ${currentAccount.password}`;
        
        // Usar a Clipboard API para copiar o texto
        navigator.clipboard.writeText(textToCopy)
            .then(() => {
                // Feedback visual temporário
                const originalText = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
                
                // Mostrar notificação simples
                showNotification('Conta copiada com sucesso!');
                
                setTimeout(() => {
                    copyBtn.innerHTML = originalText;
                }, 2000);
            })
            .catch(err => {
                fallbackCopy(textToCopy);
            });
    });
    
    // Método de fallback para copiar (navegadores antigos)
    function fallbackCopy(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        document.body.appendChild(textarea);
        textarea.select();
        
        try {
            document.execCommand('copy');
            const originalText = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
            
            setTimeout(() => {
                copyBtn.innerHTML = originalText;
            }, 2000);
        } catch (err) {
            alert('Não foi possível copiar automaticamente. Por favor, copie manualmente.');
        }
        
        document.body.removeChild(textarea);
    }
    
    // Mostrar notificação simples
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 500);
        }, 3000);
    }
    
    // Adicionar botão de recarregar
    const reloadBtn = document.createElement('button');
    reloadBtn.className = 'btn reload-btn';
    reloadBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Recarregar';
    reloadBtn.addEventListener('click', function() {
        location.reload();
    });
    
    // Adicionar botão após o contador
    document.querySelector('.status-container').appendChild(reloadBtn);
});
